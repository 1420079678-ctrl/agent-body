/**
 * @dsh-external/dsh-pentagi — PentAGI 多智能体渗透大脑（Pentest AGI Brain）
 *
 * 架构移植自 vxcontrol/pentagi（俄罗斯 VXControl 团队开源，7.2K★）：
 *   - 13 个专业 Agent（Primary/Pentester/Coder/Installer/Assistant +
 *     Searcher/Enricher/Memorist/Generator/Reporter/Adviser/Reflector/Planner）
 *   - Planner 生成阶段化任务图 → Primary 按图推进 → Adviser 在失败时自动换路
 *     → Reflector 复盘 → Memorist 知识沉淀（越用越聪明）→ Reporter 出报告
 *
 * 与 sec-* 攻击插件的关系（配套互补）：
 *   sec-workbench 的 40+ 个 sec_* 工具 = 「手」（单点执行：扫描/利用/爆破/取证）
 *   本插件 = 「脑」（编排/推进/反思/记忆/报告），每一步都绑定到具体 sec_* 工具
 *
 * 工具集（7 个，全确定性、零 token、零外部依赖——pgvector/Neo4j 用本地 JSON+关键词索引替代）：
 *   agi_team    13 角色编组表 + sec_* 工具绑定 + 调用时机（指挥图）
 *   agi_plan    作战计划：目标+意图 → 阶段化任务流（建 flow，含每步工具/参数/判据/备选）
 *   agi_flow    任务流管理：status/list/update/close（推进时回报结果）
 *   agi_next    Next-Best-Action 推进器：读 flow → 下一步该哪个角色用什么工具；失败自动 Adviser 变体
 *   agi_memory  Memorist 知识库：add/search/stats/forget（成功路径沉淀，下次直接复用）
 *   agi_reflect Reflector 复盘：有效/无效模式提炼，可一键写入记忆库
 *   agi_report  Reporter 报告：flow 执行记录 → 标准渗透测试报告落盘
 *
 * 形态：toolkit。规范：所有资源注册挂 ctx.effect（热重载/卸载自动清理）。
 */
import type { Context } from 'cordis';
export declare const name = "@dsh-external/dsh-pentagi";
export declare const inject: string[];
export interface Config {
    /** 首轮锚定：首个工具调用前只露作战入口（省首轮 prefill） */
    anchorFirstTurn: boolean;
    /** 报告输出目录（空 = DSH 插件数据目录 reports 子目录） */
    outDir: string;
}
export declare const Config: any;
export interface StepAlt {
    tool: string;
    args: Record<string, string>;
    why: string;
}
export interface Step {
    n: number;
    phase: string;
    role: string;
    tool: string;
    args: Record<string, string>;
    criteria: string;
    status: 'pending' | 'active' | 'done' | 'failed' | 'skipped';
    attempts: number;
    result: string;
    alts?: StepAlt[];
    adviser?: boolean;
    parentN?: number;
}
export interface Flow {
    id: string;
    target: string;
    goal: string;
    kind: string;
    scope: string;
    createdAt: string;
    updatedAt: string;
    closed: boolean;
    steps: Step[];
    findings: string[];
}
export interface MemEntry {
    id: string;
    ts: string;
    title: string;
    scenario: string;
    tags: string[];
    tech: string[];
    cve: string[];
    pattern: string;
    chain: string;
    pitfalls: string;
    hits: number;
}
interface PhaseDef {
    key: string;
    name: string;
}
export declare const PHASES: PhaseDef[];
/**
 * Planner 核心：按 kind 生成阶段化任务图。
 * 每一步绑定本机真实可用的工具；失败路径预置 Adviser 备选（alts）。
 */
export declare function planSteps(target: string, goal: string, kind: string): Step[];
export declare function wantsReverse(target: string, goal: string): boolean;
export interface NextAction {
    done: boolean;
    phase?: string;
    progress?: string;
    role?: string;
    tool?: string;
    args?: Record<string, string>;
    criteria?: string;
    adviserNote?: string;
    reportHint?: string;
}
/** Primary 推进器：返回下一步动作；失败步已被 adviseOnFail 换成备选变体 */
export declare function nextAction(flow: Flow): NextAction;
/** 步骤失败时的 Adviser 介入：追加备选变体步（每步最多 2 次），无备选则跳过 */
export declare function adviseOnFail(flow: Flow, stepN: number): string;
export declare function memAdd(e: Omit<MemEntry, 'id' | 'ts' | 'hits'>): MemEntry;
export declare function memAll(): MemEntry[];
export declare function memSearch(query: string, limit?: number): Array<MemEntry & {
    score: number;
}>;
export declare function memBumpHits(id: string): void;
export declare function apply(ctx: Context, config: Config): void;
export {};
