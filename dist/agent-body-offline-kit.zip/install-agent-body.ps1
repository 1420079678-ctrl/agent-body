# install-agent-body.ps1 — install the organs from the tarballs in this folder.
# No network needed: every package is included here.
#
# Usage:  pwsh .\install-agent-body.ps1
#         pwsh .\install-agent-body.ps1 -Profile headless
param([string]$Profile = 'web')

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dir = Join-Path $here 'tarballs'
if (-not (Test-Path $dir)) { Write-Error "tarballs/ not found next to this script"; exit 1 }

# the three that make a working body; the rest are optional organs
$core = @(
  'dsh-external-dsh-organism-0.1.1.tgz',
  'dsh-external-dsh-cortex-0.1.1.tgz',
  'dsh-external-dsh-zero-residence-0.1.0.tgz'
)

$paths = @()
foreach ($f in $core) {
  $p = Join-Path $dir $f
  if (Test-Path $p) { $paths += $p } else { Write-Warning "missing: $f" }
}
if ($paths.Count -eq 0) { Write-Error 'no tarballs found'; exit 1 }

Write-Host "installing into profile '$Profile':" -ForegroundColor Cyan
$paths | ForEach-Object { Write-Host "  $(Split-Path -Leaf $_)" }

dsh plugin --profile $Profile add @paths
if ($LASTEXITCODE -ne 0) { Write-Error "dsh plugin add failed (exit $LASTEXITCODE)"; exit $LASTEXITCODE }

Write-Host ""
Write-Host "done. Restart the harness, then run body_status to list the organs." -ForegroundColor Green
Write-Host "Optional extra organs are in tarballs\ — add any of them the same way:"
Write-Host "  dsh plugin --profile $Profile add .\tarballs\<name>.tgz"
