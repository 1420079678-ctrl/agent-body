/**
 * @dsh-external/dsh-mastery-loop — 精通闭环学习系统（Mastery Loop）
 *
 * 源自抖音「理科学习 Skill」方法论（识别考点→拆解条件→建立模型→选择方法→复盘错误），
 * 取其精华（思维模板化、系统节点观、反刷题堆量），去其糟粕（科目局限、孤立讲题、
 * 无记忆层），泛化创新为「任何科目」的掌握闭环：
 *
 *   orient 定位 → deconstruct 拆解 → model 建模 → diagnose 诊断
 *   → transfer 迁移 → review 复盘 → path 路径（间隔重复 × 知识图谱）
 *
 * 形态：toolkit（7 个模型侧工具）+ systemPrompt 方法论注入。
 * 规范：所有资源注册挂 ctx.effect（热重载/卸载自动清理）。
 *
 * @module @dsh-external/dsh-mastery-loop
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "@dsh-external/dsh-mastery-loop";
export declare const inject: string[];
export interface Config {
    /** 是否启用首轮锚定（首轮只露核心工具，首个工具调用后恢复全部） */
    anchorFirstTurn: boolean;
}
export declare const Config: any;
export declare function apply(ctx: Context, config: Config): void;
