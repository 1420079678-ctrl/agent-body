/**
 * @dsh-external/dsh-reverse-skill — reverse-skill 精髓移植（逆向 / 破解 / 攻击方法论引擎）
 *
 * 来源：https://github.com/zhaoxuya520/reverse-skill（安全任务技能路由包）
 * 本插件**不复制**它的 48 个 SKILL.md 正文，而是把它真正稀缺的四层能力搬进 DSH，
 * 直接作用于我们的破解/攻击工具链（sec_* / agi_* / vuln_*）：
 *
 *   1. 确定性路由引擎 —— routing.json（44 条 PRIMARY 规则）单一路由事实源，
 *      关键字 must / mustAll / exclude 匹配 + priority 计分裁决，移植自 master-route.ps1。
 *   2. 决策质量层（ADF R1–R51）+ 分析盲区手册（BS R52–R81）—— 置信带、
 *      validated 需 ≥2 条独立证据、负证据、阶段偏差自检、上下文污染、计划死锁重规划。
 *   3. 证据链契约（Evidence→Finding→Path）+ 可复现 hash 校验 —— 与我们的
 *      sec_evidence / sec_findings 同构，补上 reverse-skill 的 hash 固定与图审查。
 *   4. 自进化闭环 —— field-journal 经验回写 + 预加载先例 + 按需懒加载。
 *
 * 工具集（6 个，全确定性、零 token、零外部依赖、零网络）：
 *   rev_route      任务 → PRIMARY 技能 + 置信度 + 依据 + 本机工具绑定（先路由后动手）
 *   rev_playbook   48 个领域技能目录 / 读某技能的 SKILL.md / 读其 references（渐进披露）
 *   rev_doctrine   方法论：adf 决策框架 / blindspot 盲区手册 / evidence 证据契约 /
 *                  role 角色 / timeline 覆盖 / supply-chain / workflow 阶段门
 *   rev_case       案件链：init/scope/evidence/finding/path/timeline/workitem/status/review(hash 校验)
 *   rev_journal    经验库：add/search/index/precedent（脱敏回写，下次同类先检索）
 *   rev_toolindex  工具自举：bootstrap-manifest 能力 → 本机真实路径探测（不猜路径）
 *
 * 形态：toolkit。所有资源挂 ctx.effect（热重载/卸载自动清理）。
 */
import type { Context } from 'cordis';
export declare const name = "@dsh-external/dsh-reverse-skill";
export declare const inject: string[];
export interface Config {
    /** reverse-skill 仓库根（空 = 自动探测） */
    repoRoot: string;
    /** 案件根目录（空 = $DSH_HOME/plugins/dsh-reverse-skill/cases） */
    caseRoot: string;
    /** 首轮锚定：首个工具调用前只露入口工具 */
    anchorFirstTurn: boolean;
}
export declare const Config: any;
/** 自动探测 reverse-skill 仓库根（含 skills/config/routing.json 才算命中）。 */
export declare function resolveRepoRoot(configured?: string): string;
export interface KwRule {
    must?: string;
    mustAll?: string[];
    exclude?: string;
    note?: string;
}
export interface RouteDef {
    label: string;
    skill: string;
    keywords: KwRule[];
}
export interface RoutingCfg {
    meta: {
        fallbackId: string;
    };
    routes: Record<string, RouteDef>;
    priority: string[];
}
export interface RuleHit {
    id: string;
    label: string;
    must: string;
    note?: string;
}
export interface RouteResult {
    primary: string;
    label: string;
    skill: string;
    confidence: 'high' | 'medium' | 'low';
    scores: Record<string, number>;
    ruleHits: RuleHit[];
    matchedIds: string[];
    secondary: string[];
    notes: string[];
}
/** 读取 routing.json（唯一路由事实源）。 */
export declare function loadRouting(repo: string): RoutingCfg | null;
/**
 * 纯路由裁决（与 master-route.ps1 语义一一对应）：
 * 逐条关键字规则命中则计入候选；同 id 多次命中累加分；
 * 按 priority 顺序取最高分者为 PRIMARY，并列时 priority 靠前者胜出；
 * 无命中回退 fallbackId。confidence: 只有一个候选路由=high，多候选=medium，回退=low。
 */
export declare function routeHint(cfg: RoutingCfg, hint: string): RouteResult;
export interface ModuleInfo {
    module: string;
    label: string;
    hasSkill: boolean;
    sub: boolean;
}
/** 列出全部领域技能模块（目录含 SKILL.md 才算模块）。 */
export declare function listModules(repo: string): ModuleInfo[];
/** 读模块的 SKILL.md 或其 references 下的单个文件。 */
export declare function readModule(repo: string, module: string, file?: string): {
    ok: boolean;
    text: string;
    rel: string;
};
/** 内置提炼版方法论：不必读文件即可获得核心纪律（省 token）。 */
export declare const DOCTRINE: Record<string, string>;
export interface CaseArgs {
    action: string;
    case?: string;
    title?: string;
    target?: string;
    intent?: string;
    scope?: string;
    id?: string;
    severity?: string;
    category?: string;
    status?: string;
    evidenceIds?: string;
    location?: string;
    impact?: string;
    confidence?: string;
    remediation?: string;
    reproCommand?: string;
    sourceType?: string;
    sourceRef?: string;
    artifactPath?: string;
    rawExcerpt?: string;
    workitem?: string;
    pathType?: string;
    start?: string;
    goal?: string;
    steps?: string;
    residualRisks?: string;
    note?: string;
}
export declare function caseAction(config: Config, a: CaseArgs): string;
export declare function journalAction(config: Config, action: string, args: Record<string, string | undefined>): string;
/** 懒加载先例：任务开始前查库（供 rev_route 自动附带）。 */
export declare function journalPrelude(config: Config, hint: string): string;
interface Capability {
    name: string;
    bootstrapKind?: string;
    docsUrl?: string;
    canAutoInstall?: boolean;
    verifyCommand?: string;
    manualInstallHint?: string;
    installDir?: string;
    pinnedVersion?: string;
    pipPackage?: string;
    /** MCP server 名：注册型能力（remote-http-mcp / local-http-mcp）以它判定是否已登记到客户端 */
    mcpNames?: string[];
    /** 本地 MCP 服务的监听端口：以端口是否在监听判定服务型能力 */
    servicePort?: number;
}
/** 在 PATH 中查找可执行文件（不 spawn 进程，纯 fs，快且无副作用）。 */
export declare function whichSync(cmd: string, extraDirs?: string[]): string | null;
export declare function loadManifest(repo: string): Capability[];
export interface ToolRow {
    name: string;
    found: string | null;
    auto: boolean;
    hint: string;
}
export declare function scanTools(repo: string, want?: string): ToolRow[];
export declare function apply(ctx: Context, config: Config): void;
export {};
