import type { Context } from 'cordis';
export declare const name = "@dsh-external/dsh-academic-research";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
