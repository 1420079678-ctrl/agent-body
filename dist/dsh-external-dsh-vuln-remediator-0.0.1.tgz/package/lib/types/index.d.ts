/**
 * @dsh-external/dsh-vuln-remediator — CVE 漏洞修复与智能补丁工作台（Vuln Remediator）
 *
 * 集「发现 → 排序 → 虚拟补丁 → 修复闭环」于一身，对标世界最先进的漏洞修复技术栈：
 *
 *   发现（扫描）：
 *     vuln_scan        目标综合扫描：服务/组件指纹 → 版本 → CVE 关联 → HTTP 安全基线
 *                      → 端口探测，输出「漏洞发现清单」（node 原生，确定性，零外部 API）
 *     vuln_cve         CVE 详情 + 在野/KEV + 利用条件 + 虚拟补丁特征 查询（内置高价值组件库）
 *     vuln_sbom        SBOM 依赖审计 + 可达性降级（依赖 → 已公开 CVE → 是否被实际调用）
 *
 *   排序（动态风险评分，EPSS/VPR 式）：
 *     vuln_priority    多维度特征（CVSS/利用成熟度/KEV/暴露面/时间衰减/资产关键性）
 *                      → 0-1 动态风险分数 + 优先级标签（本地加权+逻辑回归模型）
 *
 *   虚拟补丁（不改代码、不重启、网络层止血）：
 *     vuln_patch_gen     CVE/Payload → ModSecurity / nginx / Snort 拦截规则自动生成
 *     vuln_patch_verify  规则验证：正常/恶意样本匹配测试，判误杀/漏杀 + 置信度
 *
 *   修复闭环：
 *     vuln_remediate    智能体修复方案（代码级/配置级/网络层 + 影响面 + 回滚 + 沙箱验证清单）
 *     vuln_plan        修复优先级排期（结合资产关键性 + 风险，输出里程碑）
 *
 *   知识：
 *     vuln_knowledge    漏洞修复知识库（EPSS/虚拟补丁/可达性/修复闭环/KEV）
 *
 * 形态：toolkit（9 工具，7 确定性 + 2 模型侧）+ systemPrompt 方法论注入。
 * 规范：所有资源注册挂 ctx.effect（热重载/卸载自动清理）。
 */
import type { Context } from 'cordis';
export declare const name = "@dsh-external/dsh-vuln-remediator";
export declare const inject: string[];
export interface Config {
    anchorFirstTurn: boolean;
}
export declare const Config: any;
export declare function apply(ctx: Context, config: Config): void;
