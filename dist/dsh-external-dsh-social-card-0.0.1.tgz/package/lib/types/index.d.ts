/**
 * @dsh-external/dsh-social-card — Guizang Social Card Skill 的 DSH 落地
 *
 * 把一个「Agent 驱动式设计系统」转成 DSH toolkit 插件：
 *   - 设计智能（选主题/排版/配色/文案压缩）= agent 按注入的方法论 + 可读参考文档执行
 *   - 确定性执行（能稳定产出正确尺寸 PNG）= 本插件工具
 *
 * 工具集（4 个核心 + 1 文档读取）：
 *   social_card_docs     返回指定参考文档全文（设计系统来源）
 *   social_card_scaffold 从种子模板建任务文件夹（复制 index.html + 设主题/accent）
 *   social_card_render   用 Chrome(CDP) 渲染 index.html 里每个 .poster/.pair-preview 节点成 PNG
 *   social_card_validate 跑 QA 校验器（R1-R9）
 *
 * 渲染引擎（核心，跨平台）：
 *   - 定位本机 Chrome/Chromium（env 覆盖 → 系统路径 → ms-playwright 缓存）
 *   - 优先连接「已运行 chrome」的 CDP（避免重复起进程）；找不到则自己 spawn（stdio:ignore）
 *   - 在浏览器上下文打开 file://index.html，等待字体/WebGL 就绪
 *   - 对每个 .poster/.pair-preview 节点 element.screenshot() → 原生尺寸 PNG 到 output/
 *
 * 规范：所有资源注册挂 ctx.effect（热重载/卸载自动清理，注入器踩坑记录）。
 */
import type { Context } from 'cordis';
export declare const name = "@dsh-external/dsh-social-card";
export declare const inject: string[];
export interface Config {
    /** 任务输出根目录（空 = DSH 插件数据目录 social-card 子目录） */
    outRoot: string;
    /** Chrome/Chromium 可执行文件（空 = 自动探测） */
    chromePath: string;
    /** 渲染时是否等待字体/网络空闲（模板依赖 Google Fonts + WebGL 背景） */
    waitForFonts: boolean;
}
export declare const Config: any;
export declare function apply(ctx: Context, config: Config): void;
