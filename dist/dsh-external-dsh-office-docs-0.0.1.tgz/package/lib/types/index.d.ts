import type { Context } from 'cordis';
export declare const name = "@dsh-external/dsh-office-docs";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
